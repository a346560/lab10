#ifndef FOO_H
#define DOCTEST_H
#pragma once

namespace foo {
    bool return_true();
}

#endif
