#include <tacopie/tacopie>

int main() {
}
