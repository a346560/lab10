

//  Report jsoncpp version

#include <json/json.h>

int main (void)
{
    return 0;
}
