#include "mpark/variant.hpp"

int main (void)
{
    return 0;
}
