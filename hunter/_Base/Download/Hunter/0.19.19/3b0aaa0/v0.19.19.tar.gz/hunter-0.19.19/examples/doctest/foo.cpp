#include "foo.hpp"

namespace foo {
    bool return_true() { return true; }
}
