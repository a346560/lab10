#include "foo.hpp"

namespace ns_foo {
    bool return_true() { return true; }
}
