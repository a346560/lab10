#include <SSE2NEON.h>

int main() {
}
