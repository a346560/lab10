#include <gtest/gtest.h>

TEST(Foo, Boo) {
  ASSERT_EQ(3, 3);
}
