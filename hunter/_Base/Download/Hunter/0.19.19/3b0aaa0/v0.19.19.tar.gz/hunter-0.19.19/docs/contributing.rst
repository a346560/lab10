.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Contributing
------------

* `Contribution <https://github.com/ruslo/hunter/wiki/dev.contribution>`_
