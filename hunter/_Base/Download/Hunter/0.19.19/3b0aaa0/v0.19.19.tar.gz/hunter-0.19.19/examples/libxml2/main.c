#include <libxml/tree.h>

int main(int argc, char **argv)
{
    xmlParseDoc("{}");
    return 0;
}

