Containers
----------

 * `sparsehash <https://github.com/ruslo/hunter/wiki/pkg.sparsehash>`_ - C++ associative containers
