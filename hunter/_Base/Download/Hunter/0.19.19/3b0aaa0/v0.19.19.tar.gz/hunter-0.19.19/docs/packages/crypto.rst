.. spelling::

  Crypto

Crypto
------

 * `OpenSSL <https://github.com/ruslo/hunter/wiki/pkg.openssl>`_ - open source project that provides a robust, commercial-grade, and full-featured toolkit for the Transport Layer Security (TLS>`_ and Secure Sockets Layer (SSL>`_ protocols.
