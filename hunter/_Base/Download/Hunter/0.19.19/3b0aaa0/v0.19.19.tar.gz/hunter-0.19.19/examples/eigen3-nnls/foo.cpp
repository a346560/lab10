#include <Eigen/Dense>
#include <nnls.h>

int main() {
}
