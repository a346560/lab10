#include <boost/system/config.hpp>

int main() {
}
