#include <openddlparser/OpenDDLParser.h>
#include <openddlparser/OpenDDLExport.h>

int main() {
}
