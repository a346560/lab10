.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Donations
---------

* `Donations <https://github.com/ruslo/hunter/blob/develop/donate.md>`_
