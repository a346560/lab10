.. Copyright (c) 2016-2017, Ruslan Baratov
.. All rights reserved.

Hunter user
-----------

.. toctree::
   :maxdepth: 1

   /user-guides/hunter-user/git-submodule
   /user-guides/hunter-user/nexus-cache-server

TODO
====

* add more find_packages
* add toolchain-id flags
* add hunter_add_package
* custom configs
* add package
* -> CGold
